import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { AngularFirestore, DocumentChangeAction } from '@angular/fire/compat/firestore';



@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  users: Observable<DocumentChangeAction<any>[]>;
  drivers: Observable<DocumentChangeAction<any>[]>;
  vehicleTypes: Observable<DocumentChangeAction<any>[]>;
  user = {
    first_name:'',
    last_name:'',
    contact:'',
    email:''
  };
  driver={
    driver_name: '',
    driver_license: '',
    driver_vehicle: '',
  };
  vehicleType={
    vehicle_name:'',
    vehicle_license:'',
    plate_number: ''
  };


  constructor(private firestore: AngularFirestore) {
    this.users = this.firestore.collection('users').snapshotChanges();
    this.drivers = this.firestore.collection('drivers').snapshotChanges();
    this.vehicleTypes = this.firestore.collection('vehicleTypes').snapshotChanges();
    
    
  }

  getUsers() {
    this.users.subscribe(actions => {
      actions.forEach(action => {
        console.log(action.payload.doc.id, 
          action.payload.doc.data().first_name, 
          action.payload.doc.data().last_name,
          action.payload.doc.data().contact,
          action.payload.doc.data().email);
      });
    });
  }

  getDrivers() {
    this.drivers.subscribe(actions => {
      actions.forEach(action => {
        console.log(action.payload.doc.id, 
        action.payload.doc.data().driver_name, 
        action.payload.doc.data().driver_vehicle, 
        action.payload.doc.data().driver_license);
      });
    });
  }

  getVehicleTypes() {
    this.vehicleTypes.subscribe(actions => {
      actions.forEach(action => {
        console.log(action.payload.doc.id, 
          action.payload.doc.data().vehicle_name, 
          action.payload.doc.data().plate_number, 
          action.payload.doc.data().vehicle_license);
      });
    });
  }

 
   //addUser 
    addUser(): void {
     this.firestore.collection('users').add(this.user)
     .then(()=>{
      console.log('User added succesfully');
    })
    .catch(function(error) {
      console.error('Error adding user!', error);
    });
    }
    //deleteUser
  deleteUser(user: string) {
    const userRef = this.firestore.collection('users').doc(user);
     userRef.delete().then(() => {
    
      console.log('User deleted successfully!');
      
    }).catch(error => {
      console.error('Error deleting user:', error);
    });
  }


  
  //addDriver
  addDriver():void {
    this.firestore.collection('drivers').add(this.driver)
    .then(()=>{
     console.log('Driver added succesfully');
   })
   .catch(function(error) {
     console.error('Error adding driver!', error);
   });
  }

  //deleteDriver
  deleteDriver(driver: string) {
    const driverRef = this.firestore.collection('drivers').doc(driver);
    driverRef.delete().then(() => {
      console.log('Driver deleted successfully!');
    }).catch(error => {
      console.error('Error deleting driver:', error);
    });
  }



  //addVehicle
  addVehicleType():void{
    this.firestore.collection('vehicleTypes').add(this.vehicleType)
    .then(()=>{
     console.log('Vehicle added succesfully');
   })
   .catch(function(error) {
     console.error('Error adding Vehicle!', error);
   });

  }

  //deleteVehicle
  deleteVehicleType(vehicleType: string) {
    const vehicleTypeRef = this.firestore.collection('vehicleTypes').doc(vehicleType);
    vehicleTypeRef.delete().then(() => {
      console.log('Vehicle deleted successfully!');
    }).catch(error => {
      console.error('Error deleting vehicle:', error);
    });
  }
  
  
 
}
