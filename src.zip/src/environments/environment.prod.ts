export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBFyuxWHbtSAhYUZyFGZQ7s_1c2R8Qupcc",
    authDomain: "tugxi-6f832.firebaseapp.com",
    projectId: "tugxi-6f832",
    storageBucket: "tugxi-6f832.appspot.com",
    messagingSenderId: "871006986276",
    appId: "1:871006986276:web:9c1bd14c39edf5527778b1",
    measurementId: "G-V1M8FMEYGV"
  }
};
